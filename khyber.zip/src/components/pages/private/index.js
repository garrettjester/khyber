export {default as Dashboard} from "./Dashboard";
export {default as InventoryPage} from "./InventoryPage";
export {default as CRMPage} from "./CRMPage";
export {default as DealListPage} from "./DealListPage";
export {default as TradesListPage} from "./TradesListPage";
export {default as EmployeeListPage} from "./EmployeeListPage";
export {default as DealershipPage} from "./DealershipPage";


