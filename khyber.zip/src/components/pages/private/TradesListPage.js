import React from 'react'
import PageHeader from "../../App/PageHeader"


const TradesListPage = () => {

  return (
    <div className="page-wrapper">
      <PageHeader title="Trades">

      </PageHeader>


    </div>
  )
}

export default TradesListPage;