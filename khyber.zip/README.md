## Khyber F1 🚘

A fully-managed DMS for car dealerships. Built with React/Redux & Apollo Client.

### Includes:
- Inventory Management
- Fully Digital Payments Infrastructure for Dealer Trades
- CRM
- Digital Deal Pipeline
